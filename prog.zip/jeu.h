#ifndef JEU_H
#define JEU_H

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>

#include "graphe.h"
#include "solve_astar.h"
#include "monster.h"

int jouer(SDL_Renderer * renderer);

void deplacerJoueur(int carte[][CW], SDL_Rect * pos, int direction);

#endif