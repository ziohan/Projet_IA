#include "video_player.h"
#include <libavformat/avformat.h>
#include <libavcodec/avcodec.h>
#include <libswscale/swscale.h>
#include <libavutil/imgutils.h>

static AVFormatContext   *fmt_ctx;
static AVCodecContext    *video_dec_ctx;
static int                video_stream_idx;
static struct SwsContext *sws_ctx;
static AVFrame           *frame, *frame_yuv;
static AVPacket          *pkt;
static SDL_Texture       *texture;
static SDL_Renderer      *sdl_renderer;
static int                width, height;

int video_init(const char *filename, SDL_Renderer *renderer) {
    if (avformat_open_input(&fmt_ctx, filename, NULL, NULL) < 0) return -1;
    if (avformat_find_stream_info(fmt_ctx, NULL) < 0) return -1;
    // trouve le flux vidéo
    video_stream_idx = av_find_best_stream(fmt_ctx, AVMEDIA_TYPE_VIDEO, -1, -1, NULL, 0);
    if (video_stream_idx < 0) return -1;
    AVStream *stream = fmt_ctx->streams[video_stream_idx];
    AVCodec *dec = avcodec_find_decoder(stream->codecpar->codec_id);
    video_dec_ctx = avcodec_alloc_context3(dec);
    avcodec_parameters_to_context(video_dec_ctx, stream->codecpar);
    if (avcodec_open2(video_dec_ctx, dec, NULL) < 0) return -1;

    width  = video_dec_ctx->width;
    height = video_dec_ctx->height;
    sws_ctx = sws_getContext(width, height,
                             video_dec_ctx->pix_fmt,
                             width, height,
                             AV_PIX_FMT_YUV420P,
                             SWS_BILINEAR, NULL, NULL, NULL);

    // alloue frames et packet
    frame     = av_frame_alloc();
    frame_yuv = av_frame_alloc();
    pkt       = av_packet_alloc();

    // alloue buffer YUV et crée texture SDL
    int numBytes = av_image_get_buffer_size(AV_PIX_FMT_YUV420P, width, height, 1);
    uint8_t *buffer = av_malloc(numBytes);
    av_image_fill_arrays(frame_yuv->data, frame_yuv->linesize,
                         buffer, AV_PIX_FMT_YUV420P, width, height, 1);
    texture = SDL_CreateTexture(renderer,
              SDL_PIXELFORMAT_IYUV, SDL_TEXTUREACCESS_STREAMING,
              width, height);
    sdl_renderer = renderer;
    return 0;
}

void video_play(void) {

    uint64_t startTime = SDL_GetTicks();
    
    while (av_read_frame(fmt_ctx, pkt) >= 0) {
        if (pkt->stream_index == video_stream_idx) {
            avcodec_send_packet(video_dec_ctx, pkt);
            while (avcodec_receive_frame(video_dec_ctx, frame) == 0) {
                // conversion en YUV420p
                sws_scale(sws_ctx,
                          (uint8_t const * const *)frame->data,
                          frame->linesize,
                          0, height,
                          frame_yuv->data,
                          frame_yuv->linesize);
                // upload sur la texture SDL
                SDL_UpdateYUVTexture(texture, NULL,
                                     frame_yuv->data[0], frame_yuv->linesize[0],
                                     frame_yuv->data[1], frame_yuv->linesize[1],
                                     frame_yuv->data[2], frame_yuv->linesize[2]);

                // frame->pts en unités de 'time_base'
                double pts_sec = frame->pts * av_q2d(fmt_ctx->streams[video_stream_idx]->time_base);
                // temps écoulé depuis le début en secondes
                double elapsed_sec = (SDL_GetTicks() - startTime) / 1000.0;
                // différence = quand afficher la frame
                int delay_ms = (int)((pts_sec - elapsed_sec) * 1000);
                if (delay_ms > 0) SDL_Delay(delay_ms);
                SDL_RenderClear(sdl_renderer);
                SDL_RenderCopy(sdl_renderer, texture, NULL, NULL);
                SDL_RenderPresent(sdl_renderer);
            }
        }
        av_packet_unref(pkt);
    }
}

void video_close(void) {
    SDL_DestroyTexture(texture);
    av_free(frame_yuv->data[0]);
    av_frame_free(&frame);
    av_frame_free(&frame_yuv);
    av_packet_free(&pkt);
    sws_freeContext(sws_ctx);
    avcodec_free_context(&video_dec_ctx);
    avformat_close_input(&fmt_ctx);
}
