#ifndef MAZE_KRUSKAL_H
#define MAZE_KRUSKAL_H

#include "constantes.h"  // pour VIDE, MUR :contentReference[oaicite:0]{index=0}:contentReference[oaicite:1]{index=1}
#include "graphe.h"      // pour CW, CH :contentReference[oaicite:2]{index=2}:contentReference[oaicite:3]{index=3}

typedef struct {
    int y, x;
} Wall;

/**
 * Génère un labyrinthe parfait dans grid[CH][CW] :
 *   - initialise tout en MUR
 *   - divise le domaine en “regions” (une par cellule impaire)
 *   - mélange la liste des cloisons, et retire aléatoirement chacune si elle sépare deux régions différentes
 *   - fusionne les régions jusqu’à n’en rester qu’une
 *   - marque les cellules et passages libres en VIDE
 */
void generate_maze_kruskal(int grid[CH][CW]);

#endif
