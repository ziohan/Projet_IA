#ifndef SOLVE_ASTAR_H
#define SOLVE_ASTAR_H

#include <stdlib.h>
#include <math.h>
#include "constantes.h"  // VIDE, MUR :contentReference[oaicite:4]{index=4}:contentReference[oaicite:5]{index=5}
#include "graphe.h"      // CW, CH :contentReference[oaicite:6]{index=6}:contentReference[oaicite:7]{index=7}

typedef struct {
    int x, y;
} Cell;

/**
 * Exécute A* sur la grille grid[CH][CW], de start à goal.
 * @param grid       : le labyrinthe (MUR vs VIDE)
 * @param start      : coord. de départ (colonne x, ligne y)
 * @param goal       : coord. d’arrivée
 * @param out_length : pointeur recevant la longueur du chemin renvoyé
 * @return tableau Cell* alloué dynamiquement (chemin de start à goal inclus). 
 *         _out_length vaut 0 et NULL est renvoyé si pas de chemin._  
 *         Le caller devra free() ce tableau.
 */
Cell* solve_astar(int grid[CH][CW],
                  Cell start,
                  Cell goal,
                  int *out_length);

#endif
