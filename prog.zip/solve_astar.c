#include "solve_astar.h"
//initialisation de "l'infini pour les distances"
#ifndef INFINITY
#define INFINITY 1e30 
#endif

static double heuristic(int x1, int y1, int x2, int y2) {//calcul d'une distance euclidienne pour évaluer l'heuristaque
    double dx = x2 - x1, dy = y2 - y1;
    return sqrt(dx*dx + dy*dy);
}

Cell* solve_astar(int grid[CH][CW], //labyrinthe
                  Cell start, //podition initiale de l'ennemi
                  Cell goal, //position du joueur
                  int *out_length) //liste des "poids" des chemins possibles
{
    // structures de données
    int open_flag[CH][CW]   = {0};  //tableau des cases non visité
    int closed_flag[CH][CW] = {0}; //tableau des cases visités
    double g[CH][CW], f[CH][CW]; //tableau des poids
    int parent_x[CH][CW], parent_y[CH][CW]; //tableau des cases "parent" selon les axes

    // liste “ouverte”
    int max_cells = CH * CW; 
    Cell *open_list = malloc(max_cells * sizeof(Cell));
    int open_count = 0;

    // init g/f
    for(int i = 0; i < CH; ++i)
      for(int j = 0; j < CW; ++j) {
        g[i][j] = INFINITY;
        f[i][j] = INFINITY;
      }

    g[start.y][start.x] = 0.0;
    f[start.y][start.x] = heuristic(start.x, start.y, goal.x, goal.y);

    open_list[open_count++] = start;
    open_flag[start.y][start.x] = 1;

    int found = 0;
    while(open_count > 0) {
        // 1) extraire le nœud de plus faible f
        int best_idx = 0;
        double best_f = f[ open_list[0].y ][ open_list[0].x ];
        for(int i = 1; i < open_count; ++i) {
            Cell c = open_list[i];
            if (f[c.y][c.x] < best_f) {
                best_f = f[c.y][c.x];
                best_idx = i;
            }
        }
        Cell current = open_list[best_idx];
        // retirer de open_list
        open_flag[current.y][current.x] = 0;
        open_list[best_idx] = open_list[--open_count];
        closed_flag[current.y][current.x] = 1;

        // 2) si on est arrivé
        if (current.x == goal.x && current.y == goal.y) {
            found = 1;
            break;
        }

        // 3) examiner les voisins 4-dir
        const int dirs[4][2] = {{0,-1},{0,1},{-1,0},{1,0}};
        for(int d = 0; d < 4; ++d) {
            int nx = current.x + dirs[d][0];
            int ny = current.y + dirs[d][1];
            if (!(nx < 0 || nx >= CW || ny < 0 || ny >= CH) && //si la case est dans les bornes
             grid[ny][nx] != MUR &&  //si la prochaine case est un mur
             !closed_flag[ny][nx]){   // si la prochaine case n'as pas déjà été visité
                double tentative_g = g[current.y][current.x] + 1.0;
                if (!open_flag[ny][nx] || tentative_g < g[ny][nx]) {
                    parent_x[ny][nx] = current.x;
                    parent_y[ny][nx] = current.y;
                    g[ny][nx] = tentative_g;
                    f[ny][nx] = tentative_g + heuristic(nx, ny, goal.x, goal.y);

                    if (!open_flag[ny][nx]) {
                        open_list[open_count++] = (Cell){nx, ny};
                        open_flag[ny][nx] = 1;
                    }
                }
             }
        }
    }
    free(open_list);

    if (!found) {
        *out_length = 0;
        return NULL;
    }

    // 4) reconstruction du chemin
    Cell *path = malloc(max_cells * sizeof(Cell));
    int len = 0;
    Cell p = goal;
    while (!(p.x == start.x && p.y == start.y)) {
        path[len++] = p;
        int px = parent_x[p.y][p.x];
        int py = parent_y[p.y][p.x];
        p.x = px; p.y = py;
    }
    path[len++] = start;

    // 5) renverser
    for(int i = 0; i < len/2; ++i) {
        Cell tmp = path[i];
        path[i] = path[len-1-i];
        path[len-1-i] = tmp;
    }

    *out_length = len;
    return path;
}
