#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "monster.h"

#define PATH_RECALC 20   // recalcule A* toutes les 30 frames
#define MONSTER_MOVE_DELAY 30 // Avance tous les 5 updates du monstre

void monster_init(Monster *m, int gx, int gy, int tile_size) {
    m->cell.x = gx;
    m->cell.y = gy;
    m->rect.x = gx * tile_size;
    m->rect.y = gy * tile_size;
    m->rect.w = tile_size;
    m->rect.h = tile_size;
    m->path = NULL;
    m->path_len = 0;
    m->path_idx = 0;
    m->frames = PATH_RECALC;  // pour forcer un premier calcul
    m->move_frames = 0;
}

void monster_update(Monster *m,
                    int carte[CH][CW],
                    Cell player)
{
    // 1) potentiellement recalculer le chemin
    m->frames++;
    if (m->frames >= PATH_RECALC || m->path == NULL) {
        // libération de l’ancien chemin
        if (m->path) {
            free(m->path);
            m->path = NULL;
            m->path_len = 0;
            m->path_idx = 0;
        }
        // calcule A*
        int new_len = 0;
        Cell *new_path = solve_astar(carte,
                                     m->cell,
                                     player,
                                     &new_len);
        if (new_path && new_len > 1) {
            m->path       = new_path;
            m->path_len   = new_len;
            m->path_idx   = 1;   // on saute la case 0 = position actuelle
        }
        m->frames = 0;
    }

    // 2) avancer d’une case si possible et tout les MONSTER_MOVE_DELAY frames
    m->move_frames++;
    if (m->path && m->path_idx < m->path_len && m->move_frames >= MONSTER_MOVE_DELAY) {
        Cell next = m->path[m->path_idx++];
        m->cell = next;
        m->rect.x = next.x * m->rect.w;
        m->rect.y = next.y * m->rect.h;
        m->move_frames = 0;
    }
}

void monster_draw(Monster *m,
                  SDL_Renderer *renderer,
                  SDL_Texture  *tex)
{
    SDL_RenderCopy(renderer, tex, NULL, &m->rect);
}
