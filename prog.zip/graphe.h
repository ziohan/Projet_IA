#ifndef GRAPHE_H
#define GRAPHE_H

// nombre de cellules de couloir en X et Y
#define NX 29     // on veut 16 colonnes
#define NY 17     //    et 9 lignes  → 16:9
#define D  (NX*NY) // nombre de sommets
// dimensions du tableau « maze » = couloirs+cloisons : 2×cells -1
#define CW  ((2*NX)-1)
#define CH  ((2*NY)-1)

#endif