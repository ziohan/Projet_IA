#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>

#include "jeu.h"
#include "constantes.h"



int main( int argc, char** argv){

    /*Créer une surface : Écran*/

    SDL_Window * window = NULL;
    SDL_Renderer * renderer = NULL;
    SDL_Texture * menuTexture = NULL;

    /*Variable évenement*/
    SDL_Event event;

    /*Variable pour le début du jeu*/
    bool quit = false;

    /*Ouvrir le système vidéo, obligatoire*/
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) != 0) {
        SDL_Log("Erreur d'initialisation SDL: %s\n", SDL_GetError());
        return 1;
    }


    // Initialisation SDL_image
    if (!(IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG)) {
        SDL_Log("Erreur d'initialisation d'image: %s\n", IMG_GetError());
        SDL_Quit();
        return 1;
    }

    // Création de la fenêtre
    window = SDL_CreateWindow("Zelda Labyrinth", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1920, 1080, 0);
    if (!window) {
        SDL_Log("CreateWindow Error: %s", SDL_GetError());
        return 1;
    }

    // Création du renderer
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (!renderer) {
        SDL_Log("CreateRenderer Error: %s", SDL_GetError());
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }

    // Chargement de l'icône
    SDL_Surface* iconSurface = IMG_Load("icone.png");
    if (iconSurface) {
        SDL_SetWindowIcon(window, iconSurface);
        SDL_FreeSurface(iconSurface);
    }

    // Chargement de l’image menu
    SDL_Surface* menuSurface = IMG_Load("menu.png");
    if (!menuSurface) {
        SDL_Log("Erreur de chargement de menu.png : %s", IMG_GetError());
    } else {
        menuTexture = SDL_CreateTextureFromSurface(renderer, menuSurface);
        SDL_FreeSurface(menuSurface);
    }

    // Position et taille de ton bouton “Jouer” dans le menu.png
    // (à adapter pour ton image — ici on prend un bouton centré 400×100px)
    SDL_Rect playBtn = {
        .x = (1920 - 600) / 2,   // milieu écran horizontal
        .y =  1080 - 211,   // bas de l'écran vertical
        .w = 434,
        .h = 132
    };

    // Boucle principale
    while(!quit) {

        bool running = true;

        while (running) {
            while (SDL_PollEvent(&event)) {
                if (event.type == SDL_QUIT) {
                    quit = true;
                    running = false;
                }
                else if (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE) {
                    quit = true;
                    running = false;
                }
                else if (event.type == SDL_MOUSEBUTTONDOWN
                        && event.button.button == SDL_BUTTON_LEFT)
                {
                    int mx = event.button.x;
                    int my = event.button.y;
                    if (mx >= playBtn.x && mx < playBtn.x + playBtn.w &&
                        my >= playBtn.y && my < playBtn.y + playBtn.h)
                    {
                        // l’utilisateur a cliqué sur “Jouer” → on sort du menu
                        running = false;
                    }
                }
            }

            if(quit) break;

            SDL_RenderClear(renderer);
            if (menuTexture) {
                SDL_RenderCopy(renderer, menuTexture, NULL, NULL);
            }
            SDL_RenderPresent(renderer);
        }

        if(quit) break;
    

        // Tant que l’utilisateur n’a pas quitté via “X” ou ESC :
        // (quand il clique sur le bouton Play, running devient false et on sort du menu)
        // boucle menu → partie → menu, jusqu’à ce que jouer() renvoie 1
        // affiche ton menu et attends le clic “Jouer”…
        int status = jouer(renderer);
        if (status == 1) 
            break;     // on quitte le jeu
    }

    // Nettoyage
    if (menuTexture) SDL_DestroyTexture(menuTexture);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    IMG_Quit();
    SDL_Quit();

    return EXIT_SUCCESS;
    

}