#ifndef VIDEO_PLAYER_H
#define VIDEO_PLAYER_H

#include <SDL2/SDL.h>

/** 
 * Initialise les structures FFmpeg et SDL pour la vidéo  
 */
int video_init(const char *filename, SDL_Renderer *renderer);

/** 
 * Boucle de lecture : décode et affiche chaque frame jusqu’à la fin.  
 * Retourne quand la vidéo est terminée ou en cas d’erreur.  
 */
void video_play(void);

/** 
 * Libère tout et quitte FFmpeg + SDL.  
 */
void video_close(void);

#endif  // VIDEO_PLAYER_H
