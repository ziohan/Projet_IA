#include <stdlib.h>
#include <time.h>
#include "maze_kruskal.h"

static void swap_wall(Wall *a, Wall *b) {
    Wall tmp = *a;
    *a = *b;
    *b = tmp;
}

// Fisher–Yates shuffle
static void shuffle_walls(Wall *walls, int n) {
    for (int i = n - 1; i > 0; --i) {
        int j = rand() % (i + 1);
        swap_wall(&walls[i], &walls[j]);
    }
}

void generate_maze_kruskal(int grid[CH][CW]) {
    // 1) Tout en murs
    for (int y = 0; y < CH; ++y)
        for (int x = 0; x < CW; ++x)
            grid[y][x] = MUR;

    // 2) Numérotation initiale des cellules (ou “regions”)
    int nb_regions = 0;
    for (int y = 1; y < CH - 1; y += 2)
        for (int x = 1; x < CW - 1; x += 2) {
            ++nb_regions;
            grid[y][x] = nb_regions;
        }

    // 3) Construire la liste de toutes les cloisons
    int max_walls = (CH - 2) * (CW - 2);
    Wall *walls = malloc(max_walls * sizeof(Wall));
    int wcount = 0;

    for (int y = 1; y < CH - 1; ++y) {
        for (int x = 1; x < CW - 1; ++x) {
            if ((y + x) % 2 == 1) {
                walls[wcount++] = (Wall){ y, x };
            }
        }
    }

    // 4) Mélanger, puis retirer chaque cloison si elle sépare deux régions distinctes
    srand((unsigned)time(NULL));
    shuffle_walls(walls, wcount);

    int regions = nb_regions;
    for (int i = 0; i < wcount && regions > 1; ++i) {
        int y = walls[i].y, x = walls[i].x;
        int r1, r2;

        if (y % 2 == 1) {
            // cloison verticale entre (y,x-1) et (y,x+1)
            r1 = grid[y][x - 1];
            r2 = grid[y][x + 1];
        } else {
            // cloison horizontale entre (y-1,x) et (y+1,x)
            r1 = grid[y - 1][x];
            r2 = grid[y + 1][x];
        }

        if (r1 != r2) {
            // on retire la cloison
            grid[y][x] = VIDE;
            // on fusionne les régions : toutes les cases == r2 deviennent r1
            for (int yy = 1; yy < CH; yy += 2)
                for (int xx = 1; xx < CW; xx += 2)
                    if (grid[yy][xx] == r2)
                        grid[yy][xx] = r1;
            --regions;
        }
    }
    //création de cycle en cassant des mur de manière aléatoire
    #define EXTRA_WALL_REMOVAL_PROB 100 /* en pourcentage */
    int x1,y1,x2,y2;
    for(int y = 1; y < CH - 1; ++y) {
        for(int x = 1; x < CW - 1; ++x) {
            // seules les cloisons valides (entre deux cellules) sont aux cases où y+x est impair
            if ( ((y + x) & 1) == 1 && grid[y][x] == MUR ) {
                // on regarde si de part et d'autre ce sont bien des couloirs
                if(y%2==0){
                    y1=y;
                    y2=y;
                }
                else{
                    y1=y-1;
                    y2=y+1;
                }
                if(x%2==0){
                    x1=x-1;
                    x2=x+1;
                }
                else{
                    x1=x;
                    x2=x;
                }
                if ( grid[y1][x1] == VIDE && grid[y2][x2] == VIDE && (rand() % 100) < EXTRA_WALL_REMOVAL_PROB ) {
                    grid[y][x] = VIDE;
                }
            }
        }
    }

    free(walls);

    // 5) On remet les cellules en VIDE (elles contenaient encore leur id de région)
    for (int y = 1; y < CH; y += 2)
        for (int x = 1; x < CW; x += 2)
            grid[y][x] = VIDE;
    // initialisation de l'arrivé        
    grid[CH-2][CW-2] = GOAL;
}
