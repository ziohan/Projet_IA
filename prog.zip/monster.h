#ifndef MONSTER_H
#define MONSTER_H

#include <SDL2/SDL.h>
#include "solve_astar.h"   // pour Cell
#include "constantes.h"    // pour TAILLE_BLOC
#include "graphe.h"        // pour CW, CH

typedef struct {
    Cell      cell;                // position logique (case)
    SDL_Rect  rect;                // position/fenêtre (pixels)
    Cell     *path;                // chemin A* vers le joueur
    int       path_len;            // longueur de path[]
    int       path_idx;            // où le monstre en est dans path[]
    int       frames;              // compteur pour recalcul A*
    int       move_frames;         // vitesse du monstre
} Monster;

/**
 * Initialise un monstre à la case (gx,gy).
 * tile_size = TAILLE_BLOC en général.
 */
void monster_init(Monster *m, int gx, int gy, int tile_size);

/**
 * Met à jour le monstre :
 *  - recalcule A* toutes les PATH_RECALC frames
 *  - avance d’une case le long du chemin
 * @param carte   : int[CH][CW]  (ton labyrinthe)
 * @param player  : position joueur en Cell (cases)
 */
void monster_update(Monster *m,
                    int carte[CH][CW],
                    Cell player);

/**
 * Dessine le monstre.
 */
void monster_draw(Monster *m,
                  SDL_Renderer *renderer,
                  SDL_Texture  *tex);

#endif
