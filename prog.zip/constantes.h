#ifndef CONSTANTES_H
#define CONSTANTES_H

#define TAILLE_BLOC 34

// point de départ du joueur
#define START_X         1
#define START_Y         1
// spawn initial du monstre
#define MONSTER_SPAWN_X (CW - 2)
#define MONSTER_SPAWN_Y (CH - 2)

// rayon de vision en nombre de cases
#define VISION_RADIUS 6


/*Permet de créer les directions une fois qu'on appelle ces constantes*/
enum{HAUT, BAS, GAUCHE, DROITE};

/*Definir le vide pour la map*/
enum{VIDE, MUR, LINK, GOAL};

#endif