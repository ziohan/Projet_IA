#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <math.h>

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>

#include "jeu.h"
#include "constantes.h"
#include "graphe.h"
#include "maze_kruskal.h"
#include "solve_astar.h"
#include "monster.h"
#include "video_player.h"

// couleur “sol ciel”
const SDL_Color SKY_COLOR = { 0, 0, 50, 255 };

// Zoom : 1.0 = 100%, 2.0 = 200%, etc.
static float cameraZoom = 2.0;

// La caméra (position + taille de la fenêtre virtuelle en pixels)
static SDL_Rect camera = {
    .x = 0, .y = 0,
    .w = 1920,   // largeur de la fenêtre SDL
    .h = 1080    // hauteur de la fenêtre SDL
};

// canal fixe pour le growl
#define MONSTER_CHANNEL  1

void deplacerJoueur(int carte[][CW], SDL_Rect * pos, int direction){
    //position actuelle du joueur
    int x = pos->x;
    int y = pos->y;
    /*Touche pour les deplacements*/

    switch (direction) {
        case HAUT: //déplacement vers le haut
            if (y > 0 && carte[y - 1][x] != MUR)
                pos->y--;
            break;

        case BAS: //déplacement vers le bas
            if (y < CH-1 && carte[y + 1][x] != MUR)
                 pos->y++;
             break;

        case GAUCHE: //déplacement vers la gauche
            if (x > 0 && carte[y][x - 1] != MUR)
                pos->x--;
            break;

        case DROITE: //déplacement vers la droite
            if (x < CW-1 && carte[y][x + 1] != MUR)
                 pos->x++;
             break;
    }
}

/* ----------- PERMET D'AVOIR UN CHAMP DE VISION UNIQUEMENT AVEC LA SOURIS (Pas ouf) ------------
// visible doit être statique ou passé en paramètre : int visible[CH][CW]
void compute_fov(int visible[CH][CW], int carte[][CW], int px, int py, float aim_angle)
{
    // reset
    for(int y = 0; y < CH; y++)
      for(int x = 0; x < CW; x++)
        visible[y][x] = 0;

    // on rends toujours la case du joueur visible
    visible[py][px] = 1;

    for(int r = 0; r < N_RAYS; r++) {
        // angle de ce rayon dans le cône
        float ray_ang = aim_angle 
                      - FOV_ANGLE/2 
                      + (FOV_ANGLE * r) / (N_RAYS-1);

        // direction unitaire
        float dx = cosf(ray_ang);
        float dy = sinf(ray_ang);

        // on trace le rayon de longueur VIEW_DIST
        float dist;
        for(dist = 0.0f; dist < VIEW_DIST; dist += 0.2f) {
            int cx = (int)floorf(px + dx * dist);
            int cy = (int)floorf(py + dy * dist);
            if (cx < 0 || cx >= CW || cy < 0 || cy >= CH) break;
            visible[cy][cx] = 1;
            if (carte[cy][cx] == MUR) {
                // arrêt du rayon quand on touche un mur
                break;
            }
        }
    }
}
*/

int jouer(SDL_Renderer * renderer){

    /* ======================== PARTIE INITIALISATION DES STRUCTURE ET POSITION =======================*/
    SDL_Surface *player[4] = {NULL}; 
    SDL_Texture *playerTextureBAS, *playerTextureHAUT, *playerTextureGAUCHE, *playerTextureDROITE = NULL;
    SDL_Texture *ActualTexture = NULL;
    SDL_Rect position, positionJoueur;
    SDL_Event event;
    int running = 1;
    int lives = 2;

    // Initialisation de l'aléatoire
    srand(time(NULL));

    // tableau de visibilité
    static int visible[CH][CW];
    int carte[CH][CW];
    /* génère un labyrinthe de taille c×c */
    generate_maze_kruskal(carte);

    // Position initiale du joueur
    positionJoueur.x = 1;
    positionJoueur.y = 1;

    // pour résoudre :
    Cell start = { .x = positionJoueur.x, .y = positionJoueur.y }; 
    Cell goal  = { .x = CW - 2, .y = CH - 2 };
    int path_len;
    Cell *path = solve_astar(carte, start, goal, &path_len);
    if (path) {
        // affiche/traite le chemin…
        free(path);
    }
    
    // Création du mur
    SDL_Surface * mur = IMG_Load("mur.png");  
    SDL_Texture * murTexture = SDL_CreateTextureFromSurface(renderer, mur);
    // Création de la sortie
    SDL_Surface * sortie = IMG_Load("sortie.png");
    SDL_Texture * sortietexture = SDL_CreateTextureFromSurface(renderer, sortie);

    // Charger l’image du joueur
    player[BAS] = IMG_Load("LinkBas.png");
    player[HAUT] = IMG_Load("LinkHaut.png");
    player[GAUCHE] = IMG_Load("LinkGauche.png");
    player[DROITE] = IMG_Load("LinkDroite.png");

    // Vérifie si les images sont bien chargés
    if ((!player[BAS]) && (!player[HAUT]) && (!player[GAUCHE]) && (!player[DROITE])) {
        SDL_Log("Erreur de chargement de LinkBas.png : %s", IMG_GetError());
        return 1;
    }

    // Convertir en texture une seule fois
    playerTextureBAS = SDL_CreateTextureFromSurface(renderer, player[BAS]);
    playerTextureHAUT = SDL_CreateTextureFromSurface(renderer, player[HAUT]);
    playerTextureGAUCHE = SDL_CreateTextureFromSurface(renderer, player[GAUCHE]);
    playerTextureDROITE = SDL_CreateTextureFromSurface(renderer, player[DROITE]);
    if ((!playerTextureBAS) && (!playerTextureHAUT) && (!playerTextureGAUCHE) && (!playerTextureDROITE)) {
        SDL_Log("Erreur de création de texture : %s", SDL_GetError());
        SDL_FreeSurface(player[BAS]);
        return 1;
    }

    ActualTexture = playerTextureBAS;//texture initiale du joueur

    // Crée et initialise le monstre (par ex. coin bas-droite)
    Monster monster;
    monster_init(&monster, CW-2, CH-2,TAILLE_BLOC);

    // Charger la texture du monstre
    SDL_Texture *texMonstre = IMG_LoadTexture(renderer, "monster.png");
    if (!texMonstre) {
    fprintf(stderr, "IMG_LoadTexture Error: %s\n", IMG_GetError());
    exit(1);
    }
    SDL_SetTextureBlendMode(texMonstre, SDL_BLENDMODE_BLEND);

    // Initialisation du son :
    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 1024) < 0) {
        SDL_Log("Mix_OpenAudio: %s", Mix_GetError());
        // continuer sans son, ou exit
    }

    Mix_Music *victoryMusic = Mix_LoadMUS("victoire.ogg");
    Mix_Music *screamer1 = Mix_LoadMUS("vie_1.ogg");
    Mix_Music *screamer2 = Mix_LoadMUS("vie_2.ogg");
    Mix_Music *screamer3 = Mix_LoadMUS("vie_3.ogg");
    if (!victoryMusic && !screamer1 && !screamer2 && !screamer3) {
        SDL_Log("Mix_LoadMUS: %s", Mix_GetError());
        // on continue sans son
    }

    // charge le sample de monstre
    Mix_Chunk *monsterGrowl = Mix_LoadWAV("growl.wav");
    if (!monsterGrowl) {
        SDL_Log("Mix_LoadWAV monster_growl: %s", Mix_GetError());
    }

    // lance en boucle infinie (-1 = loop forever) sur MONSTER_CHANNEL
    Mix_PlayChannel(MONSTER_CHANNEL, monsterGrowl, -1);
    // mets direct le volume à 0 (invisible tant qu’on n’est pas proche)
    Mix_Volume(MONSTER_CHANNEL, 0);

    /*Structure de Cellule pour la recherche du joueur par le monstre */
    Cell playerCell;

    

    /* ======================== PARTIE ORGANISATION DU JEU =======================*/

    while (running == 1) {
        while (SDL_PollEvent(&event)) {
            switch (event.type) {
            case SDL_QUIT:
                running = 0;
                  break;

            case SDL_KEYDOWN:
                switch (event.key.keysym.sym) {
                case SDLK_ESCAPE:
                    running = 0;
                    break;
                case SDLK_UP:
                    ActualTexture = playerTextureHAUT;                
                    deplacerJoueur(carte, &positionJoueur, HAUT);
                    break;
                case SDLK_DOWN:
                    ActualTexture = playerTextureBAS;
                    deplacerJoueur(carte, &positionJoueur, BAS);
                    break;
                case SDLK_LEFT:
                    ActualTexture = playerTextureGAUCHE;
                    deplacerJoueur(carte, &positionJoueur, GAUCHE);
                    break;
                case SDLK_RIGHT:
                    ActualTexture = playerTextureDROITE;
                    deplacerJoueur(carte, &positionJoueur, DROITE);
                    break;
                }
                break;
            }
        }


        // --- 3.1) Position du joueur en cases ---
        int px = positionJoueur.x;
        int py = positionJoueur.y;

        // rayon au carré pour éviter sqrt dans la boucle
        int r2 = VISION_RADIUS * VISION_RADIUS;

        // calcul du masque circulaire
        for (int y = 0; y < CH; y++) {
        for (int x = 0; x < CW; x++) {
            int dx = x - px;
            int dy = y - py;
            // visible si (x,y) à l’intérieur du cercle
            if(dx*dx + dy*dy <= r2){
                visible[y][x] = 1;
            }
            else{
                visible[y][x] = 0;
            }
        }
        }
        
        // === dessin unique selon cercle de visibilité ===
        SDL_SetRenderDrawColor(renderer, SKY_COLOR.r,
                                         SKY_COLOR.g,
                                         SKY_COLOR.b,
                                         SKY_COLOR.a);
        SDL_RenderClear(renderer);

        // Applique le zoom
        SDL_RenderSetScale(renderer, cameraZoom, cameraZoom);

        for (int y = 0; y < CH; y++) {
            for (int x = 0; x < CW; x++) {
                SDL_Rect dst = {
                    x * TAILLE_BLOC - camera.x,
                    y * TAILLE_BLOC - camera.y,
                    TAILLE_BLOC,
                    TAILLE_BLOC
                };
                if (!visible[y][x]) {
                    // hors du cercle : noir
                    SDL_SetRenderDrawColor(renderer, 0,0,0,255);
                    SDL_RenderFillRect(renderer, &dst);
                }
                else if (carte[y][x] == MUR) {
                    // visible + mur
                    SDL_RenderCopy(renderer, murTexture, NULL, &dst);
                }
                else if(carte[y][x] == GOAL){
                    SDL_RenderCopy(renderer, sortietexture ,NULL , &dst);
                }
                else {
                    // visible + sol (couleur ciel)
                    SDL_SetRenderDrawColor(renderer,
                        SKY_COLOR.r,
                        SKY_COLOR.g,
                        SKY_COLOR.b,
                        SKY_COLOR.a);
                    SDL_RenderFillRect(renderer, &dst);
                }
            }
        }

        // Position de dessin
        position.x = positionJoueur.x * TAILLE_BLOC - camera.x;
        position.y = positionJoueur.y * TAILLE_BLOC - camera.y;
        position.w = player[BAS]->w;
        position.h = player[BAS]->h;

        // Dessiner le joueur
        SDL_RenderCopy(renderer, ActualTexture, NULL, &position);

        //on met à jour playerCell pour refléter les coordonnées actuelles du joueur
        playerCell.x = positionJoueur.x;
        playerCell.y = positionJoueur.y;

        // Dessin du monstre et démarrage de la recherche
        monster_update(&monster, carte, playerCell);
        monster.rect.x = monster.cell.x * TAILLE_BLOC - camera.x;
        monster.rect.y = monster.cell.y * TAILLE_BLOC - camera.y;
        monster_draw(&monster, renderer, texMonstre);

        // Créer un son de rapprochement, elle augmente quand le monstre est proche du joueur et inversemment
        // distance euclidienne en cases
        float dx = (float)(monster.cell.x - playerCell.x);
        float dy = (float)(monster.cell.y - playerCell.y);
        float dist = sqrtf(dx*dx + dy*dy);

        // distance max audible (en cases) : ajustable
        const float MAX_DIST = 7.5;

        // calcule le ratio [0…1]
        float ratio = 1.0 - (dist / MAX_DIST);
        if (ratio < 0.0) ratio = 0.0;
        if (ratio > 1.0) ratio = 1.0;

        // mappe sur [0…MIX_MAX_VOLUME]
        int vol = (int)(ratio * MIX_MAX_VOLUME);
        // ajuste le volume du canal du monstre
        Mix_Volume(MONSTER_CHANNEL, vol);

        // Détection de collision  
        if (monster.cell.x == playerCell.x && monster.cell.y == playerCell.y) {

            // 1) réinitialise le joueur au début du labyrinthe
            positionJoueur.x = START_X;  // 1
            positionJoueur.y = START_Y;  // 1

            // 2) réinitialise le monstre à son spawn
            monster.cell.x = MONSTER_SPAWN_X;  
            monster.cell.y = MONSTER_SPAWN_Y; 
            monster.rect.x = monster.cell.x * TAILLE_BLOC;
            monster.rect.y = monster.cell.y * TAILLE_BLOC;
            // vide et relance son chemin
            if (monster.path) {
            free(monster.path);
            monster_init(&monster,
             MONSTER_SPAWN_X,
             MONSTER_SPAWN_Y,
             TAILLE_BLOC);
            }

            // 3) joue la vidéo du screamer
            if (lives == 0)
            {   
                if (screamer1) Mix_PlayMusic(screamer1, 1);
                if (video_init("vie_1.mp4", renderer) == 0) {
                    video_play();
                    video_close();
                }  
                return 0;
            }
            else if (lives == 2)
            {
              if (screamer3) Mix_PlayMusic(screamer3, 1);
                if (video_init("vie_3.mp4", renderer) == 0) {
                    video_play();
                    video_close();
                }  
            }
            else if (lives == 1)
            {
               if (screamer2) Mix_PlayMusic(screamer2, 1);
                if (video_init("vie_2.mp4", renderer) == 0) {
                    video_play();
                    video_close();
                } 
            }
            lives--;
            
            // On continue la boucle de jeu sans quitter ; tout est remis à zéro
            continue;

        }

        // (1) centre la caméra sur le joueur, en pixels
        int playerPx = positionJoueur.x * TAILLE_BLOC;
        int playerPy = positionJoueur.y * TAILLE_BLOC;

        // (2) calcule le coin supérieur gauche de la caméra
        camera.x = playerPx - (camera.w  / (int)cameraZoom)  / 2;
        camera.y = playerPy - (camera.h / (int)cameraZoom) / 2;

        // (3) clamp pour ne pas sortir du labyrinthe
        if (camera.x < 0) camera.x = 0;
        if (camera.y < 0) camera.y = 0;
        int maxCamX = CW * TAILLE_BLOC - (camera.w  / (int)cameraZoom);
        int maxCamY = CH * TAILLE_BLOC - (camera.h / (int)cameraZoom);
        if (camera.x > maxCamX) camera.x = maxCamX;
        if (camera.y > maxCamY) camera.y = maxCamY;

        // Détection de victoire (juste après avoir mis à jour playerCell) :
        if (playerCell.x == goal.x && playerCell.y == goal.y) {
            // joue la musique
            if (victoryMusic) Mix_PlayMusic(victoryMusic, 1);
            // lance la vidéo
            if (video_init("victoire.mp4", renderer) == 0) {
                video_play();
                video_close();
            }
            break;
        }

        // Rafraîchir l'écran
        SDL_RenderPresent(renderer);

        // ------------ DEBUG ---------------

        //Position du monstre et du joueur
        printf("Monstre en case (%d,%d) | joueur en (%d,%d) | frames=%d\n",
        monster.cell.x, monster.cell.y,
        playerCell.x, playerCell.y,
        monster.frames);
    }

    // Libérations
    if (victoryMusic && screamer1 && screamer2 && screamer3) Mix_FreeMusic(victoryMusic), Mix_FreeMusic(screamer1), Mix_FreeMusic(screamer2), Mix_FreeMusic(screamer3);
    Mix_HaltChannel(MONSTER_CHANNEL);
    if (monsterGrowl) Mix_FreeChunk(monsterGrowl);
    Mix_CloseAudio();
    SDL_DestroyTexture(ActualTexture);
    SDL_DestroyTexture(murTexture);
    SDL_DestroyTexture(texMonstre);
    SDL_FreeSurface(player[BAS]);

    return 0;

}
